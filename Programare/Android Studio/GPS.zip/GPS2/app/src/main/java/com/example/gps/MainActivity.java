package com.example.gps;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.Manifest;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;

import android.content.IntentFilter;
import android.os.Build;

import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.IOException;
import java.util.ArrayList;
import java.util.UUID;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class MainActivity extends AppCompatActivity {
    private static final int REQUEST_ENABLE_BT = 0;
    private static final int REQUEST_BLUETOOTH_PERMISSION = 1; // Poți alege orice valoare unică aici
    static final UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    BluetoothAdapter bluetoothAdapter;
    TextView info;
    private ArrayList<String> discoveredDevices = new ArrayList<>();
    private ArrayAdapter<String> arrayAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        info = findViewById(R.id.infoPannel);
        ListView deviceListView = findViewById(R.id.deviceListView);
        arrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, discoveredDevices);
        deviceListView.setAdapter(arrayAdapter);


        deviceListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                // Obține adresa și numele dispozitivului la care s-a făcut clic
                String deviceAddress = extractDataFromDeviceInfo(discoveredDevices.get(position),false);
                String deviceName = extractDataFromDeviceInfo(discoveredDevices.get(position),true);
//                System.out.println("AM AJUNS AICI");
               connectToDevice(deviceAddress,deviceName);

                }
            }
        );

        registerReceiver(bluetoothReceiver, new IntentFilter(BluetoothDevice.ACTION_FOUND));

        // Inițializează BluetoothAdapter
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        if (bluetoothAdapter == null) {
            info.setText("Bluetooth-ul nu este disponibil");
        } else {
            info.setText("Ready to go!");
        }

        Button enableButton = findViewById(R.id.enableButton);
        Button disableButton = findViewById(R.id.disableButton);
        Button Discover = findViewById(R.id.Discover);

        enableButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                enableBluetooth();
            }
        });

        Discover.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Discover();
            }
        });

        disableButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                disableBluetooth();
            }
        });
    }

    @SuppressLint("MissingPermission")
    private void enableBluetooth() {
        if (bluetoothAdapter != null) {
            // Verifică dacă Bluetooth este deja activat
            if (!bluetoothAdapter.isEnabled()) {

//                // Deschide o activitate pentru a cere permisiunea utilizatorului de a activa Bluetooth
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                showToast("Connecting now!");
                startActivityForResult(enableBtIntent,REQUEST_ENABLE_BT);
                info.setText("Bluetooth ON!");

            }
            else info.setText("Bluetooth este deja activat!");
        }
    }
    private void Discover() {
        if (bluetoothAdapter != null) {
            // Verifică dacă Bluetooth este activat
            if (bluetoothAdapter.isEnabled()) {
                // Verifică dacă permisiunea pentru locație este acordată
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    // Dacă nu este acordată, solicită permisiunea
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_BLUETOOTH_PERMISSION);
                } else {
                    // Dacă permisiunea pentru locație este acordată, începe descoperirea
                    startBluetoothDiscovery();
                }
            } else {
                showToast("Bluetooth nu este activat.");
            }
        }
    }

    private void startBluetoothDiscovery() {
        // Asigură-te că nu sunt dispozitive descoperite înainte de a începe o nouă descoperire
        if (!discoveredDevices.isEmpty()) {
            discoveredDevices.clear();
            arrayAdapter.notifyDataSetChanged();
        }

        // Începe descoperirea Bluetooth
        @SuppressLint("MissingPermission") boolean discoveryStarted = bluetoothAdapter.startDiscovery();
        if (discoveryStarted) {
            showToast("Începe descoperirea dispozitivelor Bluetooth.");
        } else {
            showToast("Descoperirea Bluetooth nu poate fi începută. Asigură-te că Bluetooth este activat.");
        }
    }

    @SuppressLint("MissingPermission")
    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Oprește descoperirea Bluetooth la distrugerea activității
        if (bluetoothAdapter != null && bluetoothAdapter.isDiscovering()) {
            bluetoothAdapter.cancelDiscovery();
        }
    }

    void showToast(String msg)
    {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
    @SuppressLint("MissingPermission")
    private void disableBluetooth() {
        discoveredDevices.clear();
        arrayAdapter.notifyDataSetChanged();

        if (bluetoothAdapter != null) {
            // Verifică dacă Bluetooth este activat
            if (bluetoothAdapter.isEnabled()) {

                // Dezactivează Bluetooth
                bluetoothAdapter.disable();
                info.setText("Bluetooth OFF!");
                showToast("Am dezactivat Bluetooth");
            }
        }
    }

    public void onRequestPermissionsResult(int requestCode,  String[] permissions,  int[] grantResults) {
        if (requestCode == REQUEST_BLUETOOTH_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permisiunea pentru Bluetooth Connect a fost acordată.
                // Acum poți continua cu acțiunile tale.
            } else {
                // Permisiunea a fost refuzată de către utilizator.
                // Poți lua măsuri suplimentare aici, cum ar fi avertizarea utilizatorului sau gestionarea altfel a situației.
            }
        } else {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        switch (requestCode){
            case REQUEST_ENABLE_BT:
                if(resultCode == RESULT_OK){
                    showToast("Se conecteaza!");
                }
                else{
                    showToast("Ceva nu a mers!");
                }
                break;
        }

        super.onActivityResult(requestCode, resultCode, data);
    }

    private String extractDataFromDeviceInfo(String deviceInfo, boolean extractName) {
        // Despărțim informațiile folosind separatorul "\n"
        String[] parts = deviceInfo.split("\n");

        // parts[0] conține numele, parts[1] conține adresa
        if (extractName) {
            return parts[0];
        } else {
            return parts[1];
        }
    }


    private final BroadcastReceiver bluetoothReceiver = new BroadcastReceiver() {
        @SuppressLint("MissingPermission")
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                if (device != null) {
                    // Verifică dacă dispozitivul nu există deja în listă
                    if (!discoveredDevices.contains(device.getName() + "\n" + device.getAddress())) {
                        // Afișează numele și adresa dispozitivului în ListView
                        String deviceInfo = device.getName() + "\n" + device.getAddress();
                        if (device.getName()!= null){
                        discoveredDevices.add(deviceInfo); // Adaugă adresa dispozitivului în listă
                        arrayAdapter.notifyDataSetChanged();}
                    }
                }
            }
        }
    };

    @SuppressLint("MissingPermission")
    private void connectToDevice(String deviceAddress, String deviceName) {
        // Verifică dacă Bluetooth este activat

        if (bluetoothAdapter == null || !bluetoothAdapter.isEnabled()) {
            // Bluetooth nu este activat, deschide un dialog pentru activare
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
            showToast("Te rog să activezi Bluetooth și să reîncerci.");
            return ;
        }else {
            // Continuă cu logica de conectare la dispozitiv
            System.out.println(deviceAddress);
            BluetoothDevice device = bluetoothAdapter.getRemoteDevice(deviceAddress);
            System.out.println(device.getName());
            // Continuă cu logica de conectare la dispozitiv


            // Creează un socket folosind UUID-ul
//                BluetoothSocket socket = device.createRfcommSocketToServiceRecord(MY_UUID);

            // Încearcă să conectezi socket-ul
//                socket.connect();
//                if(socket.isConnected()) showToast("Connected!");
            Intent intent = new Intent(MainActivity.this, DeviceDetailsActivity.class);
            intent.putExtra("DEVICE_NAME", deviceName);
            intent.putExtra("DEVICE_ADDRESS", deviceAddress);
            startActivity(intent);

        }}
}
