package com.example.gps;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;

import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.Entry;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class BluetoothDataReader extends Thread {
    private final InputStream inputStream;
    private final TextView receivedDataTextView;
    private final LineChart chart; // Adăugați graficul aici
    private final Button stopDisplay;
    private Spinner spinnerSignalSelector;

    private int packetsReceived = 0; // Contor pentru pachetele primite
    private LineDataSet dataSet;
    private LineData data;
    private float valueSelected;
    private boolean isUpdating = true;
    private float lastPitchValue= 0;
    private float lastRollValue = 0;



    public BluetoothDataReader(InputStream inputStream, TextView receivedDataTextView, LineChart chart, Spinner spinnerSignalSelector, Button stopDisplay) {
        this.inputStream = inputStream;
        this.receivedDataTextView = receivedDataTextView;
        this.chart= chart;
        this.spinnerSignalSelector=spinnerSignalSelector;
        this.stopDisplay = stopDisplay;



        dataSet = new LineDataSet(new ArrayList<>(), "Data");
        dataSet.setColor(ColorTemplate.VORDIPLOM_COLORS[1]);
        dataSet.setLineWidth(2.5f);
        dataSet.setDrawCircles(false);
        dataSet.setColor(Color.RED);
        XAxis xAxis = chart.getXAxis();
        xAxis.setTextColor(Color.WHITE); // Setează culoarea textului pentru axa X


// Pentru a schimba culoarea textului axei Y (ambele părți)
        YAxis yAxisLeft = chart.getAxisLeft();
        YAxis yAxisRight = chart.getAxisRight();
        yAxisLeft.setTextColor(Color.WHITE); // Setează culoarea textului pentru axa Y stânga
        yAxisRight.setTextColor(Color.WHITE); // Setează culoarea textului pentru axa Y dreapta
        yAxisLeft.setAxisMaximum(10);
        yAxisLeft.setAxisMinimum(-10);
        yAxisRight.setAxisMaximum(10);
        yAxisRight.setAxisMinimum(-10);
// Pentru a schimba culoarea textului legendei
        Legend legend = chart.getLegend();
        legend.setTextColor(Color.WHITE); // Setează culoarea textului pentru legendă


        data = new LineData(dataSet);
        data.setValueTextColor(ColorTemplate.VORDIPLOM_COLORS[0]);

        chart.setData(data);
        chart.invalidate(); // Refresh chart

    }
    int buffer_size = 32;
    @Override
    public void run() {
        byte[] buffer = new byte[buffer_size];
        int bytesRead;

        while (!Thread.interrupted()) {
            try {
                // Citirea datelor din InputStream
                bytesRead = inputStream.read(buffer);
                String Data = new String(buffer, 0, bytesRead);
//                System.out.println(Data);

                if (Data.startsWith("ST")){
//                        startPacketCountingTimer();

//                    dataBuilder.append(new String(buffer, 2, (bytesRead-2)));
                  String values = Data.substring(2);
//                  System.out.println(values);
                  String[] dataString = values.split(";");


                    if(spinnerSignalSelector != null)
                        spinnerSignalSelector.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                            @Override
                            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                                String selection = parent.getItemAtPosition(position).toString();

                                // Actualizează label-ul și valoarea selectată
                                updateSelectedValue(selection);
                            }

                            @Override
                            public void onNothingSelected(AdapterView<?> parent) {
                                String selection = "New Data";

                            }
                        });
                  processPacket(dataString);  //Aici trimit date spre scrierea lor pe TextView

                }

            } catch (IOException | NumberFormatException e) {
//                e.printStackTrace();
            }


        }
    }

    @SuppressLint("DefaultLocale")
    private void updateReceivedDataTextView(float accelX, float accelY, float pitch, float roll) {
        // Actualizează TextView-urile cu valorile medii ale datelor primite prin Bluetooth
        receivedDataTextView.setText(String.format("AccelX: %.4f\n AccelY: %.4f\n Pitch: %.4f\n Roll: %.4f",accelX, accelY, pitch, roll));
    }
//    private void startPacketCountingTimer() {
//        // Utilizați un timer pentru a număra pachetele în fiecare secundă
//        new Timer().scheduleAtFixedRate(new TimerTask() {
//            @Override
//            public void run() {
////                String packetsToShow = packetsReceived; // Salvează valoarea curentă
//                NrReceived.post(() -> NrReceived.setText(new String(String.valueOf(packetsReceived))));
//                // Resetați contorul
//                packetsReceived = 0;
//
//            }
//        }, 0, 1000); // Porniți timerul la fiecare 1000 milisecunde și repetați la fiecare 1000 milisecunde
//    }
    private void processPacket(String[] dataString) {
        try {
            float accelXValue = Float.parseFloat(dataString[0]);
            float accelYValue = Float.parseFloat(dataString[1]);
            float pitchValue = Float.parseFloat(dataString[2]);
            float rollValue = Float.parseFloat(dataString[3]);


//            if(lastPitchValue >50 + pitchValue || lastPitchValue < pitchValue - 50 ){pitchValue = lastPitchValue;}
//            else{lastPitchValue = pitchValue;}
//            float finalPitchValue = pitchValue;
////            dataString[2] = String.valueOf(pitchValue);
//
//
//            if(lastRollValue >50 + rollValue || lastRollValue < rollValue - 50 ){rollValue = lastRollValue;}
//            else{lastRollValue = rollValue;}
//            float finalRollValue = rollValue;
////            dataString[3] = String.valueOf(rollValue);
            if(dataString.length == 4) receivedDataTextView.post(() -> updateReceivedDataTextView(accelXValue, accelYValue, pitchValue, rollValue));
            if (spinnerSignalSelector != null && dataString.length == 4){
                if(isUpdating){
                    chart.post(()->{chart.moveViewToX(data.getEntryCount()-100);
                    chart.setVisibleXRange(0,100);
                    chart.enableScroll();}
                    );
                    chart.post(() -> {
                        data.addEntry(new Entry(dataSet.getEntryCount(), Float.parseFloat(dataString[updateSelectedValue(spinnerSignalSelector.getSelectedItem().toString())]) ), 0); // Înlocuiți accelXValue cu orice valoare vreți să plotați
                        data.notifyDataChanged();
                        chart.notifyDataSetChanged();
                        chart.setVisibleXRangeMaximum(100);
                        chart.moveViewToX(data.getEntryCount());});}
                else{
                    chart.post(()->{chart.moveViewToX(data.getEntryCount()-350);
                    chart.setVisibleXRange(0,350);

                    });

                }


                }


        } catch (NumberFormatException e) {
//            e.printStackTrace();
        }
    }

    private int updateSelectedValue(String selection) {
        switch (selection) {
            case "Accel X":
                dataSet.setLabel("Accel X");
                chart.getAxisLeft().setAxisMinimum(-10);
                chart.getAxisLeft().setAxisMaximum(10);
                return 0;
            case "Accel Y":
                dataSet.setLabel("Accel Y");
                chart.getAxisLeft().setAxisMinimum(-10);
                chart.getAxisLeft().setAxisMaximum(10);
                return 1;
            case "Pitch":
                dataSet.setLabel("Gyro X");
                chart.getAxisLeft().setAxisMinimum(-180);
                chart.getAxisLeft().setAxisMaximum(180);
                return 2;
            case "Roll":
                dataSet.setLabel("Gyro Y");
                chart.getAxisLeft().setAxisMinimum(-180);
                chart.getAxisLeft().setAxisMaximum(180);
                return 3;
            // Adaugă cazuri pentru Pitch și Roll
        }
        return 0;
    }
    public boolean isUpdating() {
        return isUpdating;
    }

    public void setUpdating(boolean updating) {
        isUpdating = updating;
        if(updating) {
        }else {
            chart.setVisibleXRangeMaximum(100);
        }
    }

}


