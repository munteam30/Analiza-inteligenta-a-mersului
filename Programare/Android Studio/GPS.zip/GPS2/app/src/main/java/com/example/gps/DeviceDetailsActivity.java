package com.example.gps;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.LineChart;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;

import jxl.write.Label;

public class DeviceDetailsActivity extends AppCompatActivity {
    private BluetoothSocket bluetoothSocket;
    private BluetoothDataReader bluetoothDataReader;
    private TextView receivedDataTextView;
    private TextView GeoLocation;
    private GPSLocationThread gpsLocationThread;
    private TextView NrReceived;
    private LineChart chart;
    private Spinner spinnerSignalSelector;
    private String Label;
    private Button stopDisplay;


    private static final UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    private OutputStream outputStream; // Adaugat pentru a trimite date prin Bluetooth

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_device_details);

        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("DEVICE_NAME") && intent.hasExtra("DEVICE_ADDRESS")) {
            String deviceName = intent.getStringExtra("DEVICE_NAME");
            String deviceAddress = intent.getStringExtra("DEVICE_ADDRESS");

            TextView nameTextView = findViewById(R.id.deviceNameTextView);
            stopDisplay= findViewById(R.id.stopDisplay);
            TextView addressTextView = findViewById(R.id.deviceAddressTextView);
            receivedDataTextView = findViewById(R.id.receivedDataTextView);
//            NrReceived = findViewById(R.id.NrReceived);
            GeoLocation = findViewById(R.id.GeoLocation);
            chart = findViewById(R.id.chart);


            stopDisplay.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    bluetoothDataReader.setUpdating(!bluetoothDataReader.isUpdating());
                }
            });

            nameTextView.setText("Nume: " + deviceName);
            addressTextView.setText("Adresa: " + deviceAddress);

            // Realizați conexiunea în această activitate
            connectToDeviceAndInitializeReader(deviceAddress);

            // Aici vreau sa adaug citirea periodica a locatiei obtinute prin gps.
            gpsLocationThread = new GPSLocationThread(this, GeoLocation);
            gpsLocationThread.start();


        }
    }

    @SuppressLint("MissingPermission")
    private void connectToDeviceAndInitializeReader(String deviceAddress) {
        try {
            bluetoothSocket = BluetoothAdapter.getDefaultAdapter().getRemoteDevice(deviceAddress)
                    .createRfcommSocketToServiceRecord(MY_UUID);
            bluetoothSocket.connect();

            // Inițializați cititorul aici, dacă doriți să începeți să citiți datele în această activitate
            initializeReader();

            // Obține OutputStream de pe BluetoothSocket pentru a trimite date
            outputStream = bluetoothSocket.getOutputStream();
//            System.out.println(GeoLocation.getText());
            sendLocation(GeoLocation.getText().toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void initializeReader() {
        // Verificați dacă bluetoothSocket este deja inițializat și conectat
        if (bluetoothSocket != null && bluetoothSocket.isConnected()) {
            try {
                // Obține InputStream de pe BluetoothSocket și inițializează BluetoothDataReader
                InputStream inputStream = bluetoothSocket.getInputStream();
                showToast("Connected!");

                Spinner spinnerSignalSelector = (Spinner) findViewById(R.id.spinnerSignalSelector);
                ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                        R.array.signal_array, android.R.layout.simple_spinner_item);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinnerSignalSelector.setAdapter(adapter);

                spinnerSignalSelector.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        // Obține semnalul selectat
                        String selectedSignal = parent.getItemAtPosition(position).toString();
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {
                        // Se poate lăsa necompletat dacă nu este necesar
                    }
                });
                bluetoothDataReader = new BluetoothDataReader(inputStream, receivedDataTextView, chart , spinnerSignalSelector, stopDisplay);

                // Începe firul de execuție pentru a citi datele
                bluetoothDataReader.start();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    // Funcție pentru a trimite locația pe socket-ul Bluetooth
    private void sendLocation(String locationData) {
        if (outputStream != null) {
            try {
                // Converteste locatia intr-un array de bytes
                byte[] locationBytes = locationData.getBytes();
                // Trimite datele prin Bluetooth
                outputStream.write("am reusit sa trimit un mesaj".getBytes());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        showToast("Connection broken.");

        // Închide BluetoothSocket și BluetoothDataReader la distrugerea activității
        try {
            if (bluetoothSocket != null) {
                bluetoothSocket.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        if (bluetoothDataReader != null) {
            bluetoothDataReader.interrupt();
        }
        if (gpsLocationThread != null) {
            gpsLocationThread.interrupt();
            gpsLocationThread.saveDataFramesToFile(); // Salvează datele înainte de a distruge activitatea
        }
    }

    void showToast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }


}
