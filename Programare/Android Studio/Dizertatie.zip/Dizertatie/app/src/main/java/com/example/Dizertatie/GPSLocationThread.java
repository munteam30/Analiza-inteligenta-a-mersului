package com.example.Dizertatie;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Handler;
import android.os.Looper;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import jxl.Workbook;

public class GPSLocationThread extends Thread {
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 123;

    private Handler mainHandler;

    private FusedLocationProviderClient fusedLocationProviderClient;
    private LocationCallback locationCallback;
    private TextView GeoLocation,locatiaSecreta;
    private WeakReference<Context> contextRef;
    private WeakReference<MainActivity> activityRef; // Referință la activitate

    private Workbook workbook;
//    private Sheet sheet;
    public GPSLocationThread(Context context, TextView GeoLocation, TextView locatiaSecreta) {
        this.contextRef = new WeakReference<>(context);
        this.GeoLocation = GeoLocation;
        this.locatiaSecreta = locatiaSecreta;
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(context);
        createLocationCallback();
        mainHandler = new Handler(Looper.getMainLooper());


    }

    @Override
    public void run() {
        requestLocationUpdates();
    }

    private void createLocationCallback() {
        locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {
                if (locationResult != null) {
                    Location location = locationResult.getLastLocation();
                    updateLocationTextView(location);
                }
            }
        };
    }

    private void requestLocationUpdates() {
        LocationRequest locationRequest = new LocationRequest();
        locationRequest.setSmallestDisplacement((float) 1 /1000);
        locationRequest.setInterval(10); // Intervalul de actualizare a locației în milisecunde
//        locationRequest.setFastestInterval(0); // Cea mai rapidă frecvență de actualizare a locației
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);

        Context context = contextRef.get();
        if (context != null && ContextCompat.checkSelfPermission(context,
                android.Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            // Folosim mainHandler pentru a posta operațiunea pe thread-ul principal
            mainHandler.post(new Runnable() {
                @SuppressLint("MissingPermission")
                @Override
                public void run() {
                    fusedLocationProviderClient.requestLocationUpdates(locationRequest, locationCallback, null);
                }
            });
        } else {
            // Dacă nu aveți permisiunea, trebuie să gestionați într-un mod corespunzător
        }
    }

    private void stopLocationUpdates() {
        fusedLocationProviderClient.removeLocationUpdates(locationCallback);
    }

    private void updateLocationTextView(Location location) {
        if (location != null) {
            double latitude = location.getLatitude();
            double longitude = location.getLongitude();
            double altitude = location.getAltitude(); // Obține altitudinea
            float speed = location.getSpeed(); // Obține viteza
//            float bearing = location.getBearing(); // Obține direcția
            long time = location.getTime(); // Obține timpul la care a fost obținută locația
            Date date = new Date(time);
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault());
            String formattedTime = sdf.format(date);

//            int lastRowNum = sheet.getLastRowNum() + 1;
//            Row dataRow = sheet.createRow(lastRowNum);
//            dataRow.createCell(0).setCellValue(latitude);
//            dataRow.createCell(1).setCellValue(longitude);
//            dataRow.createCell(2).setCellValue(altitude);
//            dataRow.createCell(3).setCellValue(speed);
//            dataRow.createCell(4).setCellValue(formattedTime);
//            String address = "Latitudine: " + latitude + "\nLongitudine: " + longitude +
//                    "\nAltitudine: " + altitude + "\nViteza: " + speed +
//                    "\nDirecția: " + bearing + "\nTimp: " + formattedTime;

            String address = "Latitudine: " + latitude + "\nLongitudine: " + longitude +
                    "\nAltitudine: " + altitude + "\nViteza: " + speed + "\nTimp: " + formattedTime;
            String address_sex = formattedTime  + ";" + longitude + ";" + latitude + ";" + altitude + ";" + speed + "\n";
            GeoLocation.setText(address);
            locatiaSecreta.setText(address_sex);

        } else {
            GeoLocation.setText("Nu s-a putut obține locația");
        }
    }

    public void saveDataFramesToFile() {
        try {
            // Obține directorul de stocare extern specific aplicației
            File externalFilesDir = contextRef.get().getExternalFilesDir(null);

            // Creează fișierul în directorul de stocare extern
            File file = new File(externalFilesDir, "DataFrames.xlsx");

            // Salvează workbook-ul în fișierul creat
            FileOutputStream fileOut = new FileOutputStream(file);
//            workbook.write(fileOut);
            fileOut.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }




};



