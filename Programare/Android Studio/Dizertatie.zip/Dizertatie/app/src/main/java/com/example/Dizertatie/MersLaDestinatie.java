package com.example.Dizertatie;

import android.Manifest;
import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.Dash;
import com.google.android.gms.maps.model.Dot;
import com.google.android.gms.maps.model.Gap;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.PatternItem;
import java.util.Arrays;
import java.util.List;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

public class MersLaDestinatie extends AppCompatActivity implements OnMapReadyCallback {
    private int inaltime;
    private BluetoothDataReader bluetoothDataReader;
    private float normalSpeedValue = 0.075f; // Viteza default, poți schimba această valoare în funcție de necesități

    private static final String TAG = "MersLaDestinatie";
    private EditText editTextAddress;
    private Button buttonNavigate;
    private TextView textViewDuration, currentSpeed, aproxTime; // TextView pentru afișarea duratei
    private GoogleMap mMap;
    private BluetoothDevice targetDevice;
    private FusedLocationProviderClient fusedLocationClient;
    private static final int REQUEST_LOCATION_PERMISSION = 1;
    private static final int REQUEST_BLUETOOTH_PERMISSION = 1;
    private static final String DIRECTIONS_API_KEY = "AIzaSyCPBh-0fNQRD98h5walTyZCsiJl6lMp1kw"; // Înlocuiește cu cheia ta API
    private static final int EARTH_RADIUS_KM = 6371;
    private boolean isTargetDeviceDiscovered = false;
    private Handler handler = new Handler();
    private Runnable updateDistanceRunnable;
    private OutputStream outputStream;
    private String predictie;
    private int factor = 1;

    private BluetoothAdapter bluetoothAdapter;
    private BluetoothSocket bluetoothSocket;
    private BluetoothDevice bluetoothDevice;
    private ArrayList<String> discoveredDevices = new ArrayList<>();
    private static final UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private boolean isDestinationReached;
    private Marker destinationMarker;

    private String getCurrentTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
        return sdf.format(new Date());
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mers_la_destinatie);

        editTextAddress = findViewById(R.id.editTextAddress);
        buttonNavigate = findViewById(R.id.buttonNavigate);
        textViewDuration = findViewById(R.id.textViewDuration); // Inițializare TextView
        currentSpeed = findViewById(R.id.currentSpeed); // Inițializare TextView
        aproxTime = findViewById(R.id.aproxTime);

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        // Obține înălțimea din Intent
        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("Inaltime")) {
            inaltime = intent.getIntExtra("Inaltime", -1);
            Toast.makeText(this, "Înălțime primită: " + inaltime, Toast.LENGTH_SHORT).show();
        }

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }
        // Initializează BluetoothDataReader


        buttonNavigate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ContextCompat.checkSelfPermission(MersLaDestinatie.this,
                        android.Manifest.permission.ACCESS_FINE_LOCATION)
                        != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(MersLaDestinatie.this,
                            new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION},
                            REQUEST_LOCATION_PERMISSION);
                } else {
                    mMap.clear();
                    getLastLocationAndNavigate();
                }
            }
        });
        // Inițializează Bluetooth-ul
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (bluetoothAdapter == null) {
            Toast.makeText(this, "Bluetooth not supported", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!bluetoothAdapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, 1);
        }
        String targetDeviceAddress = "80:C5:F2:AE:72:20"; // Adresa MAC a dispozitivului țintă --> PC
        // Specifică dispozitivul Bluetooth
        targetDevice = getBluetoothDevice(targetDeviceAddress);
        registerReceiver(bluetoothReceiver, new IntentFilter(BluetoothDevice.ACTION_FOUND));

        if (targetDevice == null) {
            Toast.makeText(this, "Nu s-a putut găsi dispozitivul țintă", Toast.LENGTH_SHORT).show();

        }
        Discover();
        int first_time = 0;
        if(isTargetDeviceDiscovered && (bluetoothSocket == null || !bluetoothSocket.isConnected())) connectBluetooth();
        for (String discoveredDeviceAddress : discoveredDevices) {
            if (discoveredDeviceAddress.equals(targetDevice.getAddress())) {
                // Dispozitivul țintă a fost descoperit
                isTargetDeviceDiscovered = true;

                if(bluetoothSocket ==null)connectBluetooth();
                else {
                    if (first_time == 1 || !bluetoothSocket.isConnected()) {
                        connectBluetooth();
                        first_time = 0;

                    }
                    else if (first_time == 0 && !bluetoothSocket.isConnected()) {
                        first_time = 1;
                    } else if (first_time == 0 && bluetoothSocket.isConnected()) {
                    }
                }
            }
        }
    }

    @SuppressLint("MissingPermission")
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.setMyLocationEnabled(true);
        mMap.setInfoWindowAdapter(new CustomInfoWindowAdapter(this));

    }
    private BluetoothDevice getBluetoothDevice(String address) {
        @SuppressLint("MissingPermission")
        Set<BluetoothDevice> pairedDevices = bluetoothAdapter.getBondedDevices();
        for (BluetoothDevice device : pairedDevices) {
            if (device.getAddress().equals(address)) {
                return device;
            }
        }
        return null;
    }
    @SuppressLint("MissingPermission")
    private double calculateDistance(LatLng start, LatLng end) {
        double latDistance = Math.toRadians(end.latitude - start.latitude);
        double lngDistance = Math.toRadians(end.longitude - start.longitude);

        double a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2)
                + Math.cos(Math.toRadians(start.latitude)) * Math.cos(Math.toRadians(end.latitude))
                * Math.sin(lngDistance / 2) * Math.sin(lngDistance / 2);

        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

        return EARTH_RADIUS_KM * c; // Distanța în kilometri
    }
    @SuppressLint("MissingPermission")
    private void connectBluetooth() {
        try {
            // Conectează-te la dispozitivul țintă prin Bluetooth
            bluetoothSocket = targetDevice.createRfcommSocketToServiceRecord(MY_UUID);
            bluetoothSocket.connect();
            if (bluetoothSocket.isConnected()) {
                InputStream inputStream = bluetoothSocket.getInputStream();
                bluetoothDataReader = new BluetoothDataReader(inputStream);
                bluetoothDataReader.start();
                Toast.makeText(this, "Connected!", Toast.LENGTH_SHORT).show();
//                startSendingLocationPeriodically(mMap);
                // Obține canalul de ieșire
                outputStream = bluetoothSocket.getOutputStream();
            } else {
                Toast.makeText(this, "No bluetooth connection!", Toast.LENGTH_SHORT).show();
            }
        } catch (IOException e) {
//            Toast.makeText(this, "Failed to connect. Exception: " + e.getMessage(), Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }

    @SuppressLint("MissingPermission")
    private void getLastLocationAndNavigate() {
        fusedLocationClient.getLastLocation().addOnSuccessListener(this, new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                if (location != null) {
                    String destinationAddress = editTextAddress.getText().toString();
                    if (!TextUtils.isEmpty(destinationAddress)) {
                        Geocoder geocoder = new Geocoder(MersLaDestinatie.this, Locale.getDefault());
                        try {
                            List<Address> addresses = geocoder.getFromLocationName(destinationAddress, 1);
                            if (addresses != null && !addresses.isEmpty()) {
                                Address address = addresses.get(0);
                                LatLng destinationLatLng = new LatLng(address.getLatitude(), address.getLongitude());

                                // Obține locația curentă
                                LatLng currentLatLng = new LatLng(location.getLatitude(), location.getLongitude());
                                String currentTime = getCurrentTime();

                                // Adaugă markere pe hartă
                                mMap.addMarker(new MarkerOptions().position(currentLatLng).title("Current Location"+ "\n"+currentTime));
                                destinationMarker = mMap.addMarker(new MarkerOptions().position(destinationLatLng).title("Destination"));
                                // Obține traseul
                                getWalkingRoute(currentLatLng, destinationLatLng);

                                // Calcularea distanței inițiale
                                double distance = calculateDistance(currentLatLng, destinationLatLng);
                                Log.d(TAG, "Distance: " + distance + " km");
//                                Toast.makeText(MersLaDestinatie.this, "Distance: " + distance + " km", Toast.LENGTH_LONG).show();

                                // Inițializează și programează actualizările periodice
                                updateDistanceRunnable = new Runnable() {
                                    @Override
                                    public void run() {
                                        fusedLocationClient.getLastLocation().addOnSuccessListener(MersLaDestinatie.this, new OnSuccessListener<Location>() {
                                            @Override
                                            public void onSuccess(Location location) {
                                                if (location != null) {
                                                    LatLng currentLatLng = new LatLng(location.getLatitude(), location.getLongitude());
                                                    updateRemainingDistance(currentLatLng, destinationLatLng);
                                                }
                                            }

                                        });
                                        handler.postDelayed(this, 3000); // Reprogramează pentru 3 secunde
                                    }
                                };
                                handler.post(updateDistanceRunnable); // Începe actualizările periodice

                            } else {
                                Toast.makeText(MersLaDestinatie.this, "Address not found", Toast.LENGTH_SHORT).show();
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    } else {
                        Toast.makeText(MersLaDestinatie.this, "Please enter a destination address", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(MersLaDestinatie.this, "Unable to get current location", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void updateRemainingDistance(LatLng currentLatLng, LatLng destinationLatLng) {

        if (bluetoothSocket != null){
            predictie = "Unknown";
            if(bluetoothSocket.isConnected()){
                predictie = bluetoothDataReader.readData();}

        }
        if(predictie.equals("Alergare"))
            factor = 2;
        else factor = 1;

        float distance = (float) calculateDistance(currentLatLng, destinationLatLng);

        if(distance > 0.01){
        String formattedDistance = String.format(Locale.US, "%.2f", distance);
        currentSpeed.setText("Remaining distance: " + formattedDistance + " km");

        if(predictie.equals("Stationare"))
            distance = 0;
        float time = (float) (distance / (0.075 * factor / 170 * inaltime)); // Aici am împartit distanta ramasa  la viteza din timpul mersului
        //Aici as vrea ca viteza sa fluctueze în functie de activitatea primita prin bluetooth
        String formattedTime = String.format(Locale.US, "%.2f", time);
        aproxTime.setText("Remaining time: " + formattedTime + " min");}
        else {
            if (!isDestinationReached) {
                isDestinationReached = true;
                String arrivalTime = getCurrentTime();
                changeDestinationMarkerColor(destinationLatLng, arrivalTime);
            }

        }
    }
    private void changeDestinationMarkerColor(LatLng destinationLatLng, String arrivalTime) {
        if (destinationMarker != null) {
            destinationMarker.remove();
        }

        destinationMarker = mMap.addMarker(new MarkerOptions()
                .position(destinationLatLng)
                .title("Destination Reached\n" + arrivalTime)
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN)));
    }

    private void getWalkingRoute(LatLng origin, LatLng destination) {
        String url = String.format("https://maps.googleapis.com/maps/api/directions/json?origin=%s,%s&destination=%s,%s&mode=walking&key=%s",
                origin.latitude, origin.longitude, destination.latitude, destination.longitude, DIRECTIONS_API_KEY);

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    URL urlObj = new URL(url);
                    HttpURLConnection connection = (HttpURLConnection) urlObj.openConnection();
                    connection.setRequestMethod("GET");
                    connection.connect();

                    BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    StringBuilder jsonResponse = new StringBuilder();
                    String line;

                    while ((line = reader.readLine()) != null) {
                        jsonResponse.append(line);
                    }

                    reader.close();
                    connection.disconnect();

                    List<LatLng> routePoints = parseDirectionsJson(jsonResponse.toString());

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (routePoints != null) {
                                drawRoute(routePoints);
                            } else {
                                Toast.makeText(MersLaDestinatie.this, "Unable to get directions", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                } catch (IOException | JSONException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    private List<LatLng> parseDirectionsJson(String json) throws JSONException {
        JSONObject jsonObject = new JSONObject(json);
        JSONArray routes = jsonObject.getJSONArray("routes");
        if (routes.length() == 0) {
            return null;
        }

        JSONObject route = routes.getJSONObject(0);
        JSONArray legs = route.getJSONArray("legs");
        JSONObject leg = legs.getJSONObject(0);
        JSONArray steps = leg.getJSONArray("steps");

        List<LatLng> points = new ArrayList<>();
        for (int i = 0; i < steps.length(); i++) {
            JSONObject step = steps.getJSONObject(i);
            JSONObject startLocation = step.getJSONObject("start_location");
            JSONObject endLocation = step.getJSONObject("end_location");

            LatLng startPoint = new LatLng(startLocation.getDouble("lat"), startLocation.getDouble("lng"));
            LatLng endPoint = new LatLng(endLocation.getDouble("lat"), endLocation.getDouble("lng"));

            points.add(startPoint);
            points.add(endPoint);
        }

        // Obține durata și actualizează UI-ul
        JSONObject duration = leg.getJSONObject("duration");
        final String durationText = duration.getString("text");
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                textViewDuration.setText("Duration: " + durationText);
            }
        });

        return points;
    }

    private void drawRoute(List<LatLng> routePoints) {
        // Definirea unui pattern de puncte și linii
        List<PatternItem> pattern = Arrays.asList(
                new Dot(), new Gap(20) // Definește un punct urmat de un spațiu de 20 de pixeli
        );

        PolylineOptions polylineOptions = new PolylineOptions()
                .width(5)
                .color(Color.BLUE)
                .pattern(pattern); // Setează pattern-ul pentru linie

        polylineOptions.addAll(routePoints);
        mMap.addPolyline(polylineOptions);
        if (!routePoints.isEmpty()) {
            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(routePoints.get(0), 15));
        }
    }


    @Override
    protected void onStop() {
        super.onStop();
        handler.removeCallbacks(updateDistanceRunnable); // Oprește actualizările periodice
    }
    private void Discover() {
        if (bluetoothAdapter != null) {
            // Verifică dacă Bluetooth este activat
            if (bluetoothAdapter.isEnabled()) {
                // Verifică dacă permisiunea pentru locație este acordată
                if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    // Dacă nu este acordată, solicită permisiunea
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_BLUETOOTH_PERMISSION);
                } else {
                    // Dacă permisiunea pentru locație este acordată, începe descoperirea
                    startBluetoothDiscovery();
                }
            }

        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_LOCATION_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getLastLocationAndNavigate();
            } else {
                Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
    private void startBluetoothDiscovery() {
        // Asigură-te că nu sunt dispozitive descoperite înainte de a începe o nouă descoperire
        if (!discoveredDevices.isEmpty()) {
//            discoveredDevices.clear();
        }

        // Începe descoperirea Bluetooth
        @SuppressLint("MissingPermission") boolean discoveryStarted = bluetoothAdapter.startDiscovery();
        if (discoveryStarted) {
//            Toast.makeText( this,"Începe descoperirea dispozitivelor Bluetooth.",Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(this,"Descoperirea Bluetooth nu poate fi începută. Asigură-te că Bluetooth este activat.",Toast.LENGTH_LONG).show();
        }
    }

    private final BroadcastReceiver bluetoothReceiver = new BroadcastReceiver() {
        @SuppressLint("MissingPermission")
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                if (device != null) {
                    // Verifică dacă dispozitivul nu există deja în listă
                    if (!discoveredDevices.contains(device.getAddress())) {
                        // Afișează numele și adresa dispozitivului în ListView
                        if (device.getAddress() != null) {
                            discoveredDevices.add(device.getAddress()); // Adaugă adresa dispozitivului în listă
                        }
                    }
                }
            }
        }
    };
}
