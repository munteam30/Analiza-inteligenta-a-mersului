package com.example.Dizertatie;


import android.annotation.SuppressLint;
import android.graphics.Color;
import android.view.View;
import android.widget.AdapterView;

import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.util.ArrayList;

public class BluetoothDataReader extends Thread {
    private final InputStream inputStream;
    private String readData;
    private boolean isUpdating = true;
    private float lastPitchValue= 0;
    private float lastRollValue = 0;



    public BluetoothDataReader(InputStream inputStream) {
        this.inputStream = inputStream;

    }
    int buffer_size = 16;
    @Override
    public void run() {
        byte[] buffer = new byte[buffer_size];
        int bytesRead;

        while (!Thread.interrupted()) {
            try {
                // Citirea datelor din InputStream
                bytesRead = inputStream.read(buffer);
                String Data = new String(buffer, 0, bytesRead);
                System.out.println(Data);

                if (Data.startsWith(";")){
                    String values = Data.substring(1);
                    readData = values;
                }

            } catch (IOException | NumberFormatException e) {
//                e.printStackTrace();
            }

        }
    }
    public String readData(){
        String predictie;
        if(readData != null) predictie = readData;
        else predictie = "Unknown";



        readData = null;
        return predictie;
    }

}



