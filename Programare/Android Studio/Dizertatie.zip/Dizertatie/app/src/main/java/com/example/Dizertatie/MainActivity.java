package com.example.Dizertatie;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends FragmentActivity implements OnMapReadyCallback {
    private String predictie;
    private static final int REQUEST_BLUETOOTH_PERMISSION = 1;
    private BluetoothAdapter bluetoothAdapter;
    private BluetoothDataReader bluetoothDataReader;
    private BluetoothDevice targetDevice;
    private BluetoothSocket bluetoothSocket;
    private OutputStream outputStream;
    private EditText messageEditText;
    private Button sendButton, connectButton, stopButton;
    private TextView GeoLocation,locatiasecreta;
    private GPSLocationThread gpsLocationThread;
    private Handler handler = new Handler();
    private Runnable periodicLocationSender;
    private GoogleMap mMap;
    private static final UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private Marker currentMarker;
    private boolean isTargetDeviceDiscovered = false;
    private List<Marker> markerList = new ArrayList<>();
    private Polyline polyline;
    private ArrayList<String> discoveredDevices = new ArrayList<>();
    private int first_time = 1;
    private boolean server = true;
    private String targetDeviceAddress;
    private String previousPredictie = "";
    private String prepreviousPredictie = "";
    private int stableCounter = 0; // Contor pentru stabilitatea predicției
    private final int STABILITY_THRESHOLD = 3; // Prag pentru stabilitate (număr de cicluri în care predicția trebuie să fie constantă)

    private static String[] PERMISSIONS_STORAGE = {
            android.Manifest.permission.READ_EXTERNAL_STORAGE,
            android.Manifest.permission.WRITE_EXTERNAL_STORAGE,
            android.Manifest.permission.ACCESS_FINE_LOCATION,
            android.Manifest.permission.ACCESS_COARSE_LOCATION,
            android.Manifest.permission.ACCESS_LOCATION_EXTRA_COMMANDS,
            android.Manifest.permission.BLUETOOTH_SCAN,
            android.Manifest.permission.BLUETOOTH_CONNECT,
            android.Manifest.permission.BLUETOOTH_PRIVILEGED
    };
    private static String[] PERMISSIONS_LOCATION = {
            android.Manifest.permission.ACCESS_FINE_LOCATION,
            android.Manifest.permission.ACCESS_COARSE_LOCATION,
            android.Manifest.permission.ACCESS_LOCATION_EXTRA_COMMANDS,
            android.Manifest.permission.BLUETOOTH_SCAN,
            android.Manifest.permission.BLUETOOTH_CONNECT,
            Manifest.permission.BLUETOOTH_PRIVILEGED
    };

    int lightBlueColor = Color.rgb(191, 73, 255);
    private void checkPermissions(){
        int permission1 = ActivityCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE);
        int permission2 = ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN);
        if (permission1 != PackageManager.PERMISSION_GRANTED) {
            // We don't have permission so prompt the user
            ActivityCompat.requestPermissions(
                    this,
                    PERMISSIONS_STORAGE,
                    1
            );
        } else if (permission2 != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(
                    this,
                    PERMISSIONS_LOCATION,
                    1
            );
        }
    }

    @SuppressLint("MissingPermission")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activity_main);
        locatiasecreta = findViewById(R.id.locatiaSecreta);
        GeoLocation = findViewById(R.id.GeoLocation);

        gpsLocationThread = new GPSLocationThread(this, GeoLocation, locatiasecreta);
        gpsLocationThread.start();
        // Inițializare Bluetooth
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        messageEditText = findViewById(R.id.messageEditText);
        sendButton = findViewById(R.id.sendButton);
        connectButton = findViewById(R.id.connectButton);
        stopButton = findViewById(R.id.stopButton);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync((OnMapReadyCallback) this);

        if (bluetoothAdapter == null) {
            Toast.makeText(this, "Dispozitivul nu suportă Bluetooth", Toast.LENGTH_SHORT).show();
            finish();
        }
        checkPermissions();

        if (!bluetoothAdapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, 1);
        }
        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("SwitchState")) {
            server = intent.getBooleanExtra("SwitchState", true);
        }
        System.out.println(server);
        // Obține dispozitivul țintă în funcție de adresa MAC cunoscută
        if (!server)
            targetDeviceAddress = "80:C5:F2:AE:72:20"; // Adresa MAC a dispozitivului țintă --> PC
        else
            targetDeviceAddress = "D8:3A:DD:C1:E1:8E"; // Adresa MAC a dispozitivului țintă --> RP5
//        String targetDeviceAddress = "C0:49:EF:E5:6C:52"; // Adresa MAC a dispozitivului țintă --> ESP

        targetDevice = getBluetoothDevice(targetDeviceAddress);
        registerReceiver(bluetoothReceiver, new IntentFilter(BluetoothDevice.ACTION_FOUND));

        if (targetDevice == null) {
            Toast.makeText(this, "Nu s-a putut găsi dispozitivul țintă", Toast.LENGTH_SHORT).show();

        }

        // Conectează-te la dispozitivul țintă prin Bluetooth o singură dată
        connectButton.setOnClickListener(v -> startSendingLocationPeriodically(mMap));
        stopButton.setOnClickListener(v -> stopLocationUpdates());


        // Configurare eveniment de trimitere
//        sendButton.setOnClickListener(v -> sendMessage());
//        startSendingLocationPeriodically();
    }

    private BluetoothDevice getBluetoothDevice(String address) {
        @SuppressLint("MissingPermission")
        Set<BluetoothDevice> pairedDevices = bluetoothAdapter.getBondedDevices();
        for (BluetoothDevice device : pairedDevices) {
            if (device.getAddress().equals(address)) {
                return device;
            }
        }
        return null;
    }

    @SuppressLint("MissingPermission")
    private void connectBluetooth() {
        try {
            // Conectează-te la dispozitivul țintă prin Bluetooth
            bluetoothSocket = targetDevice.createRfcommSocketToServiceRecord(MY_UUID);
            bluetoothSocket.connect();
            if (bluetoothSocket.isConnected()) {
                InputStream inputStream = bluetoothSocket.getInputStream();
                bluetoothDataReader = new BluetoothDataReader(inputStream);
                bluetoothDataReader.start();
                Toast.makeText(this, "Connected!", Toast.LENGTH_SHORT).show();
//                startSendingLocationPeriodically(mMap);
                // Obține canalul de ieșire
                outputStream = bluetoothSocket.getOutputStream();
            } else {
                Toast.makeText(this, "No bluetooth connection!", Toast.LENGTH_SHORT).show();
            }
        } catch (IOException e) {
//            Toast.makeText(this, "Failed to connect. Exception: " + e.getMessage(), Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }


    private void sendMessage() {
        try {
            // Trimite mesajul sub formă de șir de caractere
            String message = messageEditText.getText().toString();
            // Extrage valorile numerice din șirul original

            outputStream.write(message.getBytes());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    String oldLocation= null;
    private void startSendingLocationPeriodically(GoogleMap googleMap) {
        mMap = googleMap;
        markerList.clear();
        Discover();
        first_time = 1;
        periodicLocationSender = new Runnable() {
            @Override
            public void run() {
                if (isTargetDeviceDiscovered && (bluetoothSocket == null || !bluetoothSocket.isConnected())) connectBluetooth();
                for (String discoveredDeviceAddress : discoveredDevices) {
                    if (discoveredDeviceAddress.equals(targetDevice.getAddress())) {
                        // Dispozitivul țintă a fost descoperit
                        isTargetDeviceDiscovered = true;

                        if (bluetoothSocket == null) connectBluetooth();
                        else {
                            if (first_time == 1 || !bluetoothSocket.isConnected()) {
                                connectBluetooth();
                                first_time = 0;
                            } else if (first_time == 0 && !bluetoothSocket.isConnected()) {
                                first_time = 1;
                            }
                        }
                    }
                }

                String locatie = locatiasecreta.getText().toString();
                if (!locatie.equals(oldLocation)) {
                    oldLocation = locatie;
                    String[] Location = locatie.split(";");
                    if (Location.length > 3) {
                        LatLng locatieGPS = new LatLng(Double.parseDouble(Location[2]), Double.parseDouble(Location[1]));

                        if (bluetoothSocket != null) {
                            predictie = "Unknown";
                            if (bluetoothSocket.isConnected()) {
                                predictie = bluetoothDataReader.readData();
                            }
                        } else {
                            predictie = "Unknown";
                        }

                        String titluMarker = predictie + "\n" + Location[0];

                        // Verifică dacă predicția este la fel ca cea anterioară

                        // Adaugă un nou marker și schimbă culoarea polyline-ului
                        if(predictie.equals(previousPredictie) || predictie.equals(prepreviousPredictie)
                        )
//                            if(!predictie.equals(previousPredictie))
                            if (currentMarker != null && markerList.size() > 1 ) currentMarker.remove();
                        currentMarker = mMap.addMarker(new MarkerOptions().position(locatieGPS).title(titluMarker));
                        markerList.add(currentMarker);

                        if (markerList.size() > 1) {
                            LatLng firstPosition = markerList.get(markerList.size() - 2).getPosition();
                            LatLng currentLatLng = currentMarker.getPosition();

                            // Schimbă culoarea polyline-ului în funcție de predicție
                            int polylineColor = lightBlueColor; // Default color
                            if (predictie.equals("Mers Normal")) {
                                polylineColor = Color.RED;
                            } else if (predictie.equals("Alergare")) {
                                polylineColor = Color.GREEN;
                            }
                            // Adaugă alte condiții pentru alte valori specifice ale predicției, dacă este necesar

                            polyline = mMap.addPolyline(new PolylineOptions().add(firstPosition, currentLatLng).clickable(true).color(polylineColor));
                        }

                        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(locatieGPS, mMap.getMaxZoomLevel() - 2));
                        prepreviousPredictie = previousPredictie;
                        previousPredictie = predictie; // Actualizează predicția anterioară
                    }
                }
                if (!isTargetDeviceDiscovered) {
                    Discover();
                }
                handler.postDelayed(this, 1500);
            }
        };
        handler.postDelayed(periodicLocationSender, 1000);
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Deconectează canalul și socket-ul Bluetooth la închiderea aplicației
        try {
            if (outputStream != null) {
                outputStream.close();
            }
            if (bluetoothSocket != null ) {
                bluetoothSocket.close();
                Toast.makeText(this, "Connection broken.", Toast.LENGTH_SHORT).show();

            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;
        mMap.setInfoWindowAdapter(new CustomInfoWindowAdapter(this));
    }
    @SuppressLint("MissingPermission")
    private void stopLocationUpdates() {
        handler.removeCallbacks(periodicLocationSender);
        if (bluetoothSocket != null) {
        try {
            bluetoothSocket.close();

                if (!bluetoothSocket.isConnected())
                    Toast.makeText(this, "Conexiunea Bluetooth a fost inchisa.", Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(this, "Conexiunea Bluetooth e inca pornita. ", Toast.LENGTH_LONG).show();

            } catch(IOException ex){
                Toast.makeText(this, "Failed to connect. Exception: " + ex.getMessage(), Toast.LENGTH_LONG).show();
                ex.printStackTrace();
            }
        }
        // Poți face și alte acțiuni necesare atunci când locațiile sunt oprite
    }

    private void Discover() {
        if (bluetoothAdapter != null) {
            // Verifică dacă Bluetooth este activat
            if (bluetoothAdapter.isEnabled()) {
                // Verifică dacă permisiunea pentru locație este acordată
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    // Dacă nu este acordată, solicită permisiunea
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_BLUETOOTH_PERMISSION);
                } else {
                    // Dacă permisiunea pentru locație este acordată, începe descoperirea
                    startBluetoothDiscovery();
                }
            }

            }
        }


    private void startBluetoothDiscovery() {
        // Asigură-te că nu sunt dispozitive descoperite înainte de a începe o nouă descoperire
        if (!discoveredDevices.isEmpty()) {
//            discoveredDevices.clear();
        }

        // Începe descoperirea Bluetooth
        @SuppressLint("MissingPermission") boolean discoveryStarted = bluetoothAdapter.startDiscovery();
        if (discoveryStarted) {
//            Toast.makeText( this,"Începe descoperirea dispozitivelor Bluetooth.",Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(this,"Descoperirea Bluetooth nu poate fi începută. Asigură-te că Bluetooth este activat.",Toast.LENGTH_LONG).show();
        }
    }
    private final BroadcastReceiver bluetoothReceiver = new BroadcastReceiver() {
        @SuppressLint("MissingPermission")
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                if (device != null) {
                    // Verifică dacă dispozitivul nu există deja în listă
                    if (!discoveredDevices.contains(device.getAddress())) {
                        // Afișează numele și adresa dispozitivului în ListView
                        if (device.getAddress() != null) {
                            discoveredDevices.add(device.getAddress()); // Adaugă adresa dispozitivului în listă
                        }
                    }
                }
            }
        }
    };
}
