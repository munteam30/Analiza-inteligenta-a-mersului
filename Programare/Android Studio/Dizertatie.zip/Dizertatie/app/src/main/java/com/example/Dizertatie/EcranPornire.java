package com.example.Dizertatie;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;



public class EcranPornire extends AppCompatActivity {

    private SharedPreferences sharedPreferences;
    private EditText editText;
    private Switch switch1; // Adaugă o referință către Switch


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ecran_pornire);

        Button direction = findViewById(R.id.direction);
        Button monitor = findViewById(R.id.monitor);
        switch1 = findViewById(R.id.switch1); // Inițializează switch1 cu elementul din XML

        direction.setOnClickListener(v -> startDirections());
        monitor.setOnClickListener(v -> startMonitor());

        editText = findViewById(R.id.editTextNumber);
        sharedPreferences = getSharedPreferences("Inaltimi", MODE_PRIVATE);
    }

    protected void startDirections() {
        String numar = editText.getText().toString();
        if (!numar.isEmpty()) {
            int number = Integer.parseInt(numar);
            if (number > 150 && number < 220) {
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putInt("saved_number", number);
                editor.apply();
                Toast.makeText(this, "Inaltime salvata!", Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(EcranPornire.this, MersLaDestinatie.class);
                intent.putExtra("Inaltime", number);
                intent.putExtra("SwitchState", switch1.isChecked());
                startActivity(intent);
                Toast.makeText(this, "Bun venit în modul de ajungere la destinație!", Toast.LENGTH_SHORT).show();

            } else {
                Toast.makeText(this, "Va rog introduceti un numar valabil!", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Pentru a trece mai departe trebuie sa introduceti o înaltime.", Toast.LENGTH_LONG).show();
        }
    }


protected void startMonitor() {


    Intent intent = new Intent(EcranPornire.this, MainActivity.class);
    intent.putExtra("SwitchState", switch1.isChecked());
    startActivity(intent);
    Toast.makeText(this, "Bun venit în modul de monitorizare!", Toast.LENGTH_SHORT).show();

}
}
