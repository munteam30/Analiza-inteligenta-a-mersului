package com.example.primestelocatiasitrimite_oprinbl;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends FragmentActivity implements OnMapReadyCallback {

    private BluetoothAdapter bluetoothAdapter;
    private BluetoothDevice targetDevice;
    private BluetoothSocket bluetoothSocket;
    private OutputStream outputStream;
    private EditText messageEditText;
    private Button sendButton, connectButton;
    private TextView GeoLocation,locatiasecreta;
    private GPSLocationThread gpsLocationThread;
    private Handler handler = new Handler();
    private Runnable periodicLocationSender;
    private GoogleMap mMap;
    private static final UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private Marker currentMarker;

    @SuppressLint("MissingPermission")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);


        setContentView(R.layout.activity_main);
        locatiasecreta = findViewById(R.id.locatiaSecreta);
        GeoLocation = findViewById(R.id.GeoLocation);

        gpsLocationThread = new GPSLocationThread(this, GeoLocation, locatiasecreta);
        gpsLocationThread.start();
        // Inițializare Bluetooth
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        messageEditText = findViewById(R.id.messageEditText);
        sendButton = findViewById(R.id.sendButton);
        connectButton = findViewById(R.id.connectButton);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync((OnMapReadyCallback) this);

        if (bluetoothAdapter == null) {
            Toast.makeText(this, "Dispozitivul nu suportă Bluetooth", Toast.LENGTH_SHORT).show();
            finish();
        }

        if (!bluetoothAdapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, 1);
        }

        // Obține dispozitivul țintă în funcție de adresa MAC cunoscută
          String targetDeviceAddress = "80:C5:F2:AE:72:20"; // Adresa MAC a dispozitivului țintă --> PC

//        String targetDeviceAddress = "C0:49:EF:E5:6C:52"; // Adresa MAC a dispozitivului țintă --> ESP
        targetDevice = getBluetoothDevice(targetDeviceAddress);

        if (targetDevice == null) {
            Toast.makeText(this, "Nu s-a putut găsi dispozitivul țintă", Toast.LENGTH_SHORT).show();
            finish();
        }

        // Conectează-te la dispozitivul țintă prin Bluetooth o singură dată
        connectButton.setOnClickListener(v -> connectBluetooth());

        // Configurare eveniment de trimitere
        sendButton.setOnClickListener(v -> sendMessage());
//        startSendingLocationPeriodically();
    }

    private BluetoothDevice getBluetoothDevice(String address) {
        @SuppressLint("MissingPermission")
        Set<BluetoothDevice> pairedDevices = bluetoothAdapter.getBondedDevices();
        for (BluetoothDevice device : pairedDevices) {
            if (device.getAddress().equals(address)) {
                return device;
            }
        }
        return null;
    }

    @SuppressLint("MissingPermission")
    private void connectBluetooth() {
        try {
            // Conectează-te la dispozitivul țintă prin Bluetooth
            bluetoothSocket = targetDevice.createRfcommSocketToServiceRecord(MY_UUID);
            bluetoothSocket.connect();

            if (bluetoothSocket.isConnected()) {
                Toast.makeText(this, "Connected!", Toast.LENGTH_SHORT).show();
                startSendingLocationPeriodically(mMap);
                // Obține canalul de ieșire
                outputStream = bluetoothSocket.getOutputStream();
            } else {
                Toast.makeText(this, "Failed to connect. Please check the Bluetooth connection.", Toast.LENGTH_SHORT).show();
            }
        } catch (IOException e) {
            Toast.makeText(this, "Failed to connect. Exception: " + e.getMessage(), Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }


    private void sendMessage() {
        try {
            // Trimite mesajul sub formă de șir de caractere
            String message = messageEditText.getText().toString();
            // Extrage valorile numerice din șirul original

            outputStream.write(message.getBytes());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    String oldLocation= null;
    private void startSendingLocationPeriodically(GoogleMap googleMap) {
        mMap = googleMap;

        periodicLocationSender = new Runnable() {
            @Override
            public void run() {
//                System.out.println("Run");
                // Trimite periodic locația
                String locatie = locatiasecreta.getText().toString();

                if(!locatie.equals(oldLocation)) {
                    oldLocation=locatie;

                    if(!(bluetoothSocket.isConnected())){
                        Toast.makeText(MainActivity.this, "Not Connected!", Toast.LENGTH_LONG).show();
                        connectBluetooth();
                    }

                    String[] Location = locatie.split(";");
                    if(Location.length > 3) {
                        LatLng locatieGPS = new LatLng(Double.parseDouble(Location[2]), Double.parseDouble(Location[1])); // Înlocuiește cu locația GPS actuală
                        if (currentMarker != null) currentMarker.remove();
                        currentMarker = mMap.addMarker(new MarkerOptions().position(locatieGPS).title("Marker in locatia GPS"));
                        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(locatieGPS, mMap.getMaxZoomLevel() - 5));
                    }
                try {
                    if(Location.length > 3)
                        outputStream.write(oldLocation.getBytes());
                } catch (IOException e) {
//                    throw new RuntimeException(e);
                }}
                handler.postDelayed(this, 1500);
            }
        };
        handler.postDelayed(periodicLocationSender, 1000); // Pornirea trimiterii la început
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Deconectează canalul și socket-ul Bluetooth la închiderea aplicației
        try {
            if (outputStream != null) {
                outputStream.close();
            }
            if (bluetoothSocket != null) {
                bluetoothSocket.close();
                Toast.makeText(this, "Connection broken.", Toast.LENGTH_SHORT).show();

            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;
    }
}
